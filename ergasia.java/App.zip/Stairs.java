public class Stairs extends Inschool{
      Stairs(){
            super("Stairs");
      }
      
      void enter_Stairs(Student s){
            enter_inschool(s);
      }

      void enter_Stairs(Teacher t){
            enter_inschool(t);
      }
}
