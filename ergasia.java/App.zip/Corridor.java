public class Corridor extends Inschool2 {

      Corridor(){
            super("Corridor");
      }

      void enter_Corridor(Student s){
            enter_Class(s);
      }
}
