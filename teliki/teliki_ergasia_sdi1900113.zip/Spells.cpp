#include <iostream>
#include <string>
#include "Spells.h"

using namespace std;